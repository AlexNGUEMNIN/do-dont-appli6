$(document).ready(function () {
    function openBD() {
        const indexedDB = window.indexedDB ||
            window.mozIndexedDB ||
            window.webkitIndexedDB ||
            window.msIndexedDB ||
            window.shimIndexedDB;

        const request = indexedDB.open("ddDatabase", 1);
        return request;
    }

    let listes = [];
    var listesContainer = document.querySelector("#listesContainer");
    var statutAffichage = "grille"; // liste

    function getAllListes() {
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction("liste", "readwrite");
            const store = transaction.objectStore("liste");

            const keyword = $('#searchInput').val().trim().toLowerCase();
            console.log(keyword);

            const query = store.getAll();
            query.onsuccess = function () {
                const filteredListes = filterLitesByKeyword(query.result, keyword);
                console.log("query", filteredListes);
                $('#listesContainer').html("");
                for (let elt of filteredListes) {
                    const liste = `<div class="col-md-6 col-lg-4">
                        <div class="bg-light rounded">
                            <div class="card-body" name="cardListe"">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="mb-0">
                                        <h5 class="card-title">${elt.nom}</h5>
                                    </div>
                                    <div class="d-flex">
                                        <button type="button" class="btn btn-warning bg-light text-warning border-0 p-1 me-1 modalModifListeOpen"
                                            data-key="${elt.id}" data-nom="${elt.nom}" data-desc="${elt.description}"><i class="fa fa-pen"></i></button>
                                        <button type="button" class="btn btn-danger text-danger bg-light border-0 p-1 modalSupListeOpen"
                                            data-key="${elt.id}" data-nom="${elt.nom}"><i class="fa fa-trash"></i></button>
                                    </div>
                                </div>
                                
                                <div class="card-subtitle text-muted mb-3">${elt.dateCreation}</div>
                                <p class="card-text scroll">
                                    ${elt.description}
                                </p>
                                <a data-key="${elt.id}" href="javascript:void(0)" class="card-link viewTachesBtn">${elt.taches.length} Tâches</a>
                                <a href="javascript:void(0)" class="card-link modalAjoutTacheOpen" data-nom="${elt.nom}">Ajouter</a>
                            </div>
                        </div>
                    </div>`
                    listesContainer.insertAdjacentHTML("beforeend", liste);
                }
                addEventUpdate();
                addEventDelete();
                addEventAddTache();
                addEventViewsTaches();
            };

            transaction.oncomplete = function () {
                db.close;
            };
        };
    }
    getAllListes();

    function generateUniqueId() {
        var timestamp = Date.now().toString(36); // Convertir l'horodatage en base 36
        var randomNum = Math.random().toString(36).slice(2, 7); // Générer un nombre aléatoire
        return timestamp + randomNum; // Concaténer l'horodatage et le nombre aléatoire
    }

    let nomListe = "";
    let descriptionListe = "";
    $('#inputNom').on('input', function (elt) {
        nomListe = $(this).val();
    });
    $('#inputDescription').on('input', function (elt) {
        descriptionListe = $(this).val();
    });

    function formatDate(date) {
        const options = { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' };
        return new Date(date).toLocaleDateString('fr-FR', options);
    }

    function masquerAlert(alert) {
        alert.classList.add('fade'); // Ajoute la classe fade pour une transition de fermeture en douceur
        setTimeout(function () {
            alert.setAttribute('hidden', true); // Masquez le modal après 5 secondes (5000 millisecondes)
        }, 5000);
    }

    function createListe() {
        let now = formatDate(new Date());
        let formAjoutListe = document.getElementById('formAjoutListe');
        let champsRequis = formAjoutListe.querySelectorAll('[required]');
        let formSussess = true;
        for (let champ of champsRequis) {
            // Vérifiez si le champ est vide
            if (champ.value.trim() === '') {
                formSussess = false;
                // Affichez un message d'erreur
                $('#alert_error_ajout').html("<i class='fa fa-exclamation-circle me-2'></i>Veuillez remplir tous les champs.");
                let alert_error_ajout = document.getElementById("alert_error_ajout");
                alert_error_ajout.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_ajout);
            }
        }
        if (formSussess) {
            const request = openBD();
            request.onerror = function (event) {
                console.error("Une erreur avec IndexedDB");
                console.error(event);
            };

            request.onsuccess = function () {
                const db = request.result;
                const transaction = db.transaction("liste", "readwrite");
                const store = transaction.objectStore("liste");
                const nomListeIndex = store.index("indexNom");

                const addRequest = store.put({ id: generateUniqueId(), nom: nomListe, description: descriptionListe, dateCreation: now, taches: [] });
                addRequest.onerror = function (event) {
                    console.log(event);
                    // Vérifier si l'erreur est due à une contrainte d'unicité sur l'attribut "nom"
                    if (event.target.error && event.target.error.name === 'ConstraintError') {
                        $('#alert_error_ajout').html("<i class='fa fa-exclamation-circle me-2'></i>Le nom de liste existe déjà.");
                        let alert_error_ajout = document.getElementById("alert_error_ajout");
                        alert_error_ajout.removeAttribute('hidden'); // Affichez le modal
                        masquerAlert(alert_error_ajout);
                        console.error('Le nom de liste existe déjà.');
                    } else {
                        $('#alert_error_ajout').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la création de la liste.");
                        let alert_error_ajout = document.getElementById("alert_error_ajout");
                        alert_error_ajout.removeAttribute('hidden'); // Affichez le modal
                        masquerAlert(alert_error_ajout);
                        console.error('Erreur lors de la création de la liste :', event.target.error);
                    }
                };
                addRequest.onsuccess = function () {
                    const query = nomListeIndex.get(nomListe);
                    query.onsuccess = function () {
                        console.log("query", query.result);
                    };
                    $('#modalAjout').modal("hide");
                    var inputElements = modalAjout.querySelectorAll('input');
                    inputElements.forEach(function (input) {
                        input.value = '';
                    });
                    var textareaElements = modalAjout.querySelectorAll('textarea');
                    textareaElements.forEach(function (textarea) {
                        textarea.value = '';
                    });
                    $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Liste créée avec succès! ");
                    let alert_success_add = document.getElementById("alert_success_add");
                    alert_success_add.removeAttribute('hidden'); // Affichez le modal
                    masquerAlert(alert_success_add);
                    $('#listesContainer').html("");
                    getAllListes();
                };

                transaction.oncomplete = function () {
                    db.close;
                };
            };
        }
    }

    function deleteListe() {

        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function () {
            const db = request.result;
            // Démarrer une transaction en mode de lecture/écriture sur la table "liste"
            const transaction = db.transaction(["liste", "tache"], "readwrite");
            const store = transaction.objectStore("liste");
            const store2 = transaction.objectStore("tache");
            const nomListeIndex = store2.index("indexListe");

            var key = $('#messageSuppresion').attr("data-key");
            var oldNom = $('#messageSuppresion').attr("data-nom");
            console.log(key);
            var deleteRequest = store.delete(key);
            deleteRequest.onsuccess = function (event) {
                var getTachesRequest = nomListeIndex.getAll([oldNom]);
                getTachesRequest.onsuccess = function () {
                    var taches = getTachesRequest.result;
                    console.log(taches);
                    var deleteTacheRequests = [];
                    for (let tache of taches) {
                        var tacheDeleteRequest = store2.delete(tache.id);
                        deleteTacheRequests.push(tacheDeleteRequest);
                    }
                    // Attendre que toutes les mises à jour de tâches soient terminées
                    Promise.all(deleteTacheRequests).then(() => {
                        console.log('Liste supprimée avec succès.');
                        $('#modalSup').modal("hide");
                        $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Liste supprimée avec succès! ");
                        let alert_success_add = document.getElementById("alert_success_add");
                        alert_success_add.removeAttribute('hidden'); // Afficher le modal
                        masquerAlert(alert_success_add);
                        $('#listesContainer').html("");
                        getAllListes();
                    }).catch(error => {
                        console.error('Erreur lors de la suppression des tâches :', error);
                        $('#alert_error_modif').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la suppression des tâches.");
                        let alert_error_modif = document.getElementById("alert_error_modif");
                        alert_error_modif.removeAttribute('hidden'); // Afficher le modal
                        masquerAlert(alert_error_modif);
                    });
                }
            }

            deleteRequest.onerror = function (event) {
                console.error('Erreur lors de la suppression de la liste.');
                console.log(event);
                $('#modalSup').modal("hide");
                $('#alert_error_add').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la suppression de la liste. ");
                let alert_error_add = document.getElementById("alert_error_add");
                alert_error_add.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_add);
            }
            transaction.oncomplete = function () {
                db.close;
            };
        };
    };

    let nomListeM = "";
    let descriptionListeM = "";
    $('#inputNomModif').on('input', function (elt) {
        nomListeM = $(this).val();
    });
    $('#inputDescriptionModif').on('input', function (elt) {
        descriptionListeM = $(this).val();
    });

    function updateListe() {
        let formModifListe = document.getElementById('formModifListe');
        let champsRequis = formModifListe.querySelectorAll('[required]');
        let formSussess = true;
        for (let champ of champsRequis) {
            // Vérifiez si le champ est vide
            if (champ.value.trim() === '') {
                formSussess = false;
                // Affichez un message d'erreur
                $('#alert_error_modif').html("<i class='fa fa-exclamation-circle me-2'></i>Veuillez remplir tous les champs.");
                let alert_error_modif = document.getElementById("alert_error_modif");
                alert_error_modif.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_modif);
            }
        }
        if (formSussess) {
            const request = openBD();
            request.onerror = function (event) {
                console.error("Une erreur avec IndexedDB");
                console.error(event);
            };

            request.onsuccess = function () {
                const db = request.result;
                // Démarrer une transaction en mode de lecture/écriture sur la table "liste"
                const transaction = db.transaction(["liste", "tache"], "readwrite");
                const store = transaction.objectStore("liste");
                const store2 = transaction.objectStore("tache");
                const nomListeIndex = store2.index("indexListe");

                var key = $('#inputNomModif').attr("data-key");
                console.log(key);
                var getRequest = store.get(key);
                getRequest.onsuccess = function (event) {
                    var liste = event.target.result;
                    console.log(liste);
                    let oldNom = liste.nom;
                    console.log("oldNom : ", oldNom);

                    // Modifier les propriétés de l'objet
                    liste.nom = nomListeM; // Nouveau nom
                    liste.description = descriptionListeM; // Nouvelle description
                    for (let tache of liste.taches) {
                        tache.liste = nomListeM;
                    }
                    // Mettre à jour l'objet modifié dans la base de données en utilisant put()
                    var updateRequest = store.put(liste);
                    // Gérer le succès ou l'échec de la requête de mise à jour
                    updateRequest.onsuccess = function (event) {
                        var getTachesRequest = nomListeIndex.getAll([oldNom]);
                        getTachesRequest.onsuccess = function () {
                            var taches = getTachesRequest.result;
                            console.log(taches);
                            var updateTacheRequests = [];
                            for (let tache of taches) {
                                tache.liste = nomListeM;
                                // Mettre à jour chaque tâche dans la base de données
                                var tacheUpdateRequest = store2.put(tache);
                                updateTacheRequests.push(tacheUpdateRequest);
                            }
                            // Attendre que toutes les mises à jour de tâches soient terminées
                            Promise.all(updateTacheRequests).then(() => {
                                console.log('Tâches mises à jour avec succès.');
                                $('#modalModif').modal("hide");
                                $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Liste modifiée avec succès! ");
                                let alert_success_add = document.getElementById("alert_success_add");
                                alert_success_add.removeAttribute('hidden'); // Afficher le modal
                                masquerAlert(alert_success_add);
                                $('#listesContainer').html("");
                                getAllListes();
                            }).catch(error => {
                                console.error('Erreur lors de la mise à jour des tâches :', error);
                                $('#alert_error_modif').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la mise à jour des tâches.");
                                let alert_error_modif = document.getElementById("alert_error_modif");
                                alert_error_modif.removeAttribute('hidden'); // Afficher le modal
                                masquerAlert(alert_error_modif);
                            });
                        }
                    };


                    updateRequest.onerror = function (event) {
                        console.log(event);
                        // Vérifier si l'erreur est due à une contrainte d'unicité sur l'attribut "nom"
                        if (event.target.error && event.target.error.name === 'ConstraintError') {
                            $('#alert_error_modif').html("<i class='fa fa-exclamation-circle me-2'></i>Le nom de liste existe déjà.");
                            let alert_error_modif = document.getElementById("alert_error_modif");
                            alert_error_modif.removeAttribute('hidden'); // Affichez le modal
                            masquerAlert(alert_error_modif);
                            console.error('Le nom de liste existe déjà.');
                        } else {
                            $('#alert_error_modif').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la mise à jour de la liste.");
                            let alert_error_modif = document.getElementById("alert_error_modif");
                            alert_error_modif.removeAttribute('hidden'); // Affichez le modal
                            masquerAlert(alert_error_modif);
                            console.error('Erreur lors de la mise à jour de la liste :', event.target.error);
                        }
                    };
                };

                getRequest.onerror = function (event) {
                    console.error('Erreur lors de la récupération de la liste.');
                };

                transaction.oncomplete = function () {
                    db.close;
                };
            };
        }

    }

    let nomTache = "";
    let descriptionTache = "";
    let dateFin = "";
    let heureFin = "";
    $('#inputNomTache').on('input', function (elt) {
        nomTache = $(this).val();
    });
    $('#inputDescriptionTache').on('input', function (elt) {
        descriptionTache = $(this).val();
    });
    $('#inputDate').on('input', function (elt) {
        dateFin = $(this).val();
    });
    $('#inputHeure').on('input', function (elt) {
        heureFin = $(this).val();
    });

    function createTache() {
        var liste = $("#inputListe").val();
        console.log(nomTache);
        console.log(descriptionTache);
        console.log(dateFin);
        console.log(heureFin);
        console.log(liste);
        let formAjoutTache = document.getElementById('formAjoutTache');
        let champsRequis = formAjoutTache.querySelectorAll('[required]');
        let formSussess = true;
        for (let champ of champsRequis) {
            // Vérifiez si le champ est vide
            if (champ.value.trim() === '') {
                formSussess = false;
                // Affichez un message d'erreur
                $('#alert_error_tache').html("<i class='fa fa-exclamation-circle me-2'></i>Veuillez remplir tous les champs.");
                let alert_error_tache = document.getElementById("alert_error_tache");
                alert_error_tache.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_tache);
            }
        }

        if (formSussess) {
            nowDate = new Date();
            let now = formatDate(nowDate);
            // Séparer la date en année, mois et jour
            let [year, month, day] = dateFin.split('-').map(Number);
            // Séparer l'heure en heures et minutes
            let [hours, minutes] = heureFin.split(':').map(Number);
            // Créer un objet Date en utilisant les valeurs extraites
            let dateHeureFin = new Date(year, month - 1, day, hours, minutes);
            if (nowDate >= dateHeureFin) {
                // Affichez un message d'erreur
                $('#alert_error_tache').html("<i class='fa fa-exclamation-circle me-2'></i>La date d'échéance est passée.");
                let alert_error_tache = document.getElementById("alert_error_tache");
                alert_error_tache.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_tache);
            } else {
                const request = openBD();
                request.onerror = function (event) {
                    console.error("Une erreur avec IndexedDB");
                    console.error(event);
                };
                request.onsuccess = function () {
                    const db = request.result;
                    const transaction = db.transaction(["tache", "liste"], "readwrite");
                    const store = transaction.objectStore("tache");
                    const nomTacheListeIndex = store.index("indexNom_Liste");
                    const store2 = transaction.objectStore("liste");
                    const nomListeIndex = store2.index("indexNom");

                    const addRequest = store.put({ id: generateUniqueId(), nom: nomTache, description: descriptionTache, dateCreation: now, dateEcheance: formatDate(dateHeureFin), statut: "A faire", liste: liste });
                    addRequest.onerror = function (event) {
                        console.log(event);
                        // Vérifier si l'erreur est due à une contrainte d'unicité sur l'attribut "nom, liste"
                        if (event.target.error && event.target.error.name === 'ConstraintError') {
                            $('#alert_error_tache').html("<i class='fa fa-exclamation-circle me-2'></i>Ce nom de tâche existe déjà dans cette liste.");
                            let alert_error_tache = document.getElementById("alert_error_tache");
                            alert_error_tache.removeAttribute('hidden'); // Affichez le modal
                            masquerAlert(alert_error_tache);
                            console.error('Le nom de liste existe déjà.');
                        } else {
                            $('#alert_error_tache').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la création de la tâche.");
                            let alert_error_tache = document.getElementById("alert_error_tache");
                            alert_error_tache.removeAttribute('hidden'); // Affichez le modal
                            masquerAlert(alert_error_tache);
                            console.error('Erreur lors de la création de la liste :', event.target.error);
                        }
                    };
                    addRequest.onsuccess = function () {
                        const query = nomTacheListeIndex.get([nomTache, liste]);
                        query.onsuccess = function () {
                            console.log("query", query.result);
                            var getListeRequest = nomListeIndex.get([liste]);
                            getListeRequest.onsuccess = function (event) {
                                var l = event.target.result;
                                console.log(l);
                                // Modifier les propriétés de l'objet
                                l.taches.push(query.result); // Nouveau nom
                                // Mettre à jour l'objet modifié dans la base de données en utilisant put()
                                var updateListeRequest = store2.put(l);
                                // Gérer le succès ou l'échec de la requête de mise à jour
                                updateListeRequest.onsuccess = function (event) {
                                    $('#modalAjoutTache').modal("hide");
                                    var inputElements = modalAjoutTache.querySelectorAll('input');
                                    inputElements.forEach(function (input) {
                                        input.value = '';
                                    });
                                    var textareaElements = modalAjoutTache.querySelectorAll('textarea');
                                    textareaElements.forEach(function (textarea) {
                                        textarea.value = '';
                                    });
                                    $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Tache créée avec succès! ");
                                    let alert_success_add = document.getElementById("alert_success_add");
                                    alert_success_add.removeAttribute('hidden'); // Affichez le modal
                                    masquerAlert(alert_success_add);
                                    $('#listesContainer').html("");
                                    getAllListes();
                                };
                            };
                        };
                    };

                    transaction.oncomplete = function () {
                        db.close;
                    };
                };
            }
        }
    }

    $('#addListeBtn').on("click", function () {
        createListe()
    });
    $('#deleteListeBtn').on("click", function () {
        deleteListe()
    });

    function addEventUpdate() {
        // Ajouter un écouteur d'événement pour chaque bouton "modifier"
        const modifButtons = document.querySelectorAll('.modalModifListeOpen');
        modifButtons.forEach(button => {
            button.addEventListener('click', function () {
                const nomData = this.getAttribute('data-nom');
                const descData = this.getAttribute('data-desc');
                const keyData = this.getAttribute('data-key');
                // Ouvrir le modal de modification et pré-remplir le formulaire avec les informations de la liste
                openModificationModal(nomData, descData, keyData);
            });
        });
    }
    function addEventDelete() {
        // Ajouter un écouteur d'événement pour chaque bouton "supprimer"
        const supButtons = document.querySelectorAll('.modalSupListeOpen');
        supButtons.forEach(button => {
            button.addEventListener('click', function () {
                const nomData = this.getAttribute('data-nom');
                const keyData = this.getAttribute('data-key');
                // Ouvrir le modal de confirmation de la suppression
                openSuppressionModal(nomData, keyData);
            });
        });
    }
    function addEventViewsTaches() {
        // Ajouter un écouteur d'événement pour chaque bouton "supprimer"
        const viewButtons = document.querySelectorAll('.viewTachesBtn');
        viewButtons.forEach(button => {
            button.addEventListener('click', function () {
                const listId = this.getAttribute('data-key');
                console.log(listId);
                getListe(listId).then((liste) => {
                    if(liste){
                        const params = new URLSearchParams();
                        params.append('listId', listId);
                        window.location.href = 'viewTaches.html?' + params.toString();
                    }
                }).catch((error) => {
                    console.error("Erreur lors de la récupération de la liste:", error);
                });
            });
        });
    }
    function addEventAddTache() {
        // Ajouter un écouteur d'événement pour chaque bouton "ajouter tache"
        const ajoutButtons = document.querySelectorAll('.modalAjoutTacheOpen');
        ajoutButtons.forEach(button => {
            button.addEventListener('click', function () {
                const nomListeT = this.getAttribute('data-nom');
                openAjoutTacheModal(nomListeT);
            });
        });
    }

    function openModificationModal(nom, description, id) {
        $('#inputNomModif').val(nom);
        $('#inputNomModif').attr("data-key", id);
        $('#inputDescriptionModif').val(description);
        nomListeM = nom;
        descriptionListeM = description;
        $('#modalModif').modal("show");
    }
    function openSuppressionModal(nom, id) {
        $('#messageSuppresion').attr("data-key", id);
        $('#messageSuppresion').attr("data-nom", nom);
        $('#modalSup').modal("show");
    }
    function openAjoutTacheModal(liste) {
        $('#inputListe').val(liste);
        $('#modalAjoutTache').modal("show");
    }
    $('#updateListeBtn').on("click", function () {
        updateListe()
    });
    $('#addTacheBtn').on("click", function () {
        createTache()
    });

    // Fonction de filtrage des liste en fonction du mot-clé de recherche
    function filterLitesByKeyword(listes, keyword) {
        return listes.filter(liste => {
            return liste.nom.toLowerCase().includes(keyword) || liste.description.toLowerCase().includes(keyword) || liste.dateCreation.includes(keyword);
        });
    }

    $('#searchForm').on('submit', function (event) {
        event.preventDefault();
    });

    $('#searchInput').on('input', function () {
        getAllListes();
    });

    $('#affichageGrilleBtn').on("click", function () {
        statutAffichage = "liste";
        getAllListes();
    });

    function getListe(key) {
        return new Promise((resolve, reject) => {
            const request = openBD();
            request.onerror = function (event) {
                console.error("Une erreur avec IndexedDB");
                console.error(event);
                reject(event);
            };

            request.onsuccess = function () {
                const db = request.result;
                const transaction = db.transaction("liste", "readonly");
                const store = transaction.objectStore("liste");

                const query = store.get(key);
                query.onsuccess = function () {
                    const liste = query.result;
                    resolve(liste);
                };

                transaction.oncomplete = function () {
                    db.close(); // Fermer la base de données
                };
            };
        });
    }

});