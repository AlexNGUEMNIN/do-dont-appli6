$(document).ready(function () {
    function openBD() {
        const indexedDB = window.indexedDB ||
            window.mozIndexedDB ||
            window.webkitIndexedDB ||
            window.msIndexedDB ||
            window.shimIndexedDB;

        const request = indexedDB.open("ddDatabase", 1);
        return request;
    }

    function convertToDate(dateString) {
        // Séparation de la date et de l'heure
        var dateParts = dateString.split(' ');
        var datePart = dateParts[0];
        var timePart = dateParts[1];

        // Séparation du jour, mois, année
        var dateComponents = datePart.split('/');
        var day = parseInt(dateComponents[0]);
        var month = parseInt(dateComponents[1]) - 1; // Les mois commencent à partir de zéro dans JavaScript
        var year = parseInt(dateComponents[2]);

        // Séparation de l'heure et des minutes
        var timeComponents = timePart.split(':');
        var hour = parseInt(timeComponents[0]);
        var minute = parseInt(timeComponents[1]);

        // Création de l'objet Date
        var dateObject = new Date(year, month, day, hour, minute);

        return dateObject
    }

    // Fonction pour récupérer les tâches depuis IndexedDB
    function getTasks() {
        return new Promise((resolve, reject) => {
            const request = openBD();
            request.onerror = function (event) {
                console.error("Une erreur avec IndexedDB");
                console.error(event);
                reject(event);
            };

            request.onsuccess = function () {
                const db = request.result;
                const transaction = db.transaction("tache", "readonly");
                const store = transaction.objectStore("tache");

                const query = store.getAll();
                query.onsuccess = function () {
                    const taches = query.result;
                    resolve(taches);
                };

                transaction.oncomplete = function () {
                    db.close(); // Fermer la base de données
                };
            };
        });
    }

    // Fonction pour calculer le délai restant jusqu'à la date d'échéance
    function calculateTimeRemaining(deadline) {
        const now = new Date();
        const diff = deadline.getTime() - now.getTime();
        const diffInHours = Math.floor(diff / (1000 * 60 * 60));
        return diffInHours;
    }

    // Fonction pour générer le contenu de la notification
    function generateNotificationContent(taskCount, timeRemaining) {
        if (timeRemaining >= 0 && timeRemaining <= 1) {
            return `Vous avez ${taskCount} tâches à terminer dans moins d'une heure.`;
        } else if (timeRemaining < 24) {
            return `Vous avez ${taskCount} tâches à terminer dans ${timeRemaining} heures.`;
        } else {
            const days = Math.floor(timeRemaining / 24);
            return `Vous avez ${taskCount} tâches à terminer dans ${days} jours.`;
        }
    }

    // Fonction pour afficher la notification
    function showNotification(content) {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                new Notification('Do-Dont App, Gestion des tâches', {
                    body: content,
                    icon: "../img/logo.png",
                });
            }
        });

    }

    // Fonction principale pour gérer les notifications des tâches
    function handleTaskNotifications() {
        getTasks().then((tasks) => {
            let remainingTasks = [...tasks];
            for (let task of tasks) {
                console.log(task);
                if (task.statut === 'En cours' || task.statut === 'A faire') {
                    let tasksToDo = 0;
                    let tab = [];
                    const deadline = convertToDate(task.dateEcheance);
                    const timeRemaining = calculateTimeRemaining(deadline);
                    for (let otherTask of remainingTasks) {
                        if (otherTask.statut === 'En cours' || otherTask.statut === 'A faire') {
                            const otherDeadline = convertToDate(otherTask.dateEcheance);
                            const otherTimeRemaining = calculateTimeRemaining(otherDeadline);
                            if (otherTimeRemaining === timeRemaining) {
                                tasksToDo++;
                                tab.push(otherTask);
                            } else if (timeRemaining >= 24 && timeRemaining < 48 && otherTimeRemaining >= 24 && otherTimeRemaining < 48) {
                                tasksToDo++;
                                tab.push(otherTask);
                            } else {
                                if (timeRemaining >= 48 && timeRemaining < 72 && otherTimeRemaining >= 48 && otherTimeRemaining < 72) {
                                    tasksToDo++;
                                    tab.push(otherTask);
                                }
                            }
                        }
                    }

                    console.log(timeRemaining);
                    console.log(tasksToDo);
                    if (tasksToDo > 0 && timeRemaining <= 72) { // Notifications pour les délais de 72 heures ou moins
                        const content = generateNotificationContent(tasksToDo, timeRemaining);
                        showNotification(content);
                    }

                    // Filtrer les tâches restantes pour ne garder que celles qui n'ont pas le même délai
                    remainingTasks = remainingTasks.filter(task => {
                        return !tab.some(t => t.id === task.id);
                    })
                    // remainingTasks = remainingTasks.filter(t => {
                    //     const tDeadline = convertToDate(t.dateEcheance);
                    //     const tTimeRemaining = calculateTimeRemaining(tDeadline);
                    //     return (timeRemaining !== tTimeRemaining); // Garder seulement les tâches dont le délai est différent
                    // });
                }
            }
        }).catch((error) => {
            console.error("Erreur lors de la récupération des tâches:", error);
        });
    }

    // Appel initial de la fonction
    handleTaskNotifications()
    // Appeler la fonction toutes les 1 heure
    setInterval(handleTaskNotifications, 60000); // 60000 millisecondes = 1 minute
    //setInterval(handleTaskNotifications, 3600000); // 60000 millisecondes = 1 minute

});
