const indexedDB = window.indexedDB ||
                  window.mozIndexedDB ||
                  window.webkitIndexedDB ||
                  window.msIndexedDB ||
                  window.shimIndexedDB;

const request = indexedDB.open("ddDatabase", 1);

request.onerror = function (event) {
    console.error("Une erreur avec IndexedDB");
    console.error(event);
};

request.onupgradeneeded = function () {
    const db = request.result;
    let oldVersion = request.oldVersion;
    let newVersion = request.newVersion || db.version;
    console.log('La BD est passée de la version, ', oldVersion, ' à la version ', newVersion);
    if (!db.objectStoreNames.contains('liste')){
        const store = db.createObjectStore("liste", {keyPath: "id"});
        store.createIndex("indexNom", ["nom"], {unique: true});
        store.createIndex("indexDescription", ["description"], {unique: false});
        store.createIndex("indexDateCreation", ["dateCreation"], {unique: false});
    }
    if (!db.objectStoreNames.contains('tache')){
        const store = db.createObjectStore("tache", {keyPath: "id"});
        store.createIndex("indexNom", ["nom"], {unique: false});
        store.createIndex("indexNom_Liste", ["nom", "liste"], {unique: true});
        store.createIndex("indexDescription", ["description"], {unique: false});
        store.createIndex("indexDateCreation", ["dateCreation"], {unique: false});
        store.createIndex("indexDateEcheance", ["dateEcheance"], {unique: false});
        store.createIndex("indexStatut", ["statut"], {unique: false});
        store.createIndex("indexListe", ["liste"], {unique: false});
    }
    if (!db.objectStoreNames.contains('utilisateur')){
        const store = db.createObjectStore("utilisateur", {keyPath: "id"});
    }
    
};
request.onsuccess = function () {
    // const db = request.result;
    // const transaction = db.transaction(["liste", "tache"], "readwrite");

    // const store = transaction.objectStore("liste");
    // const nomListeIndex = store.index("indexNom");
    // const dateCreationListeIndex = store.index("indexDateCreation");

    // store.put({id: generateUniqueId(), nom: "Projets", description: "Une petite description de la liste projets. suivi des projets scolaires. Une petite description de la liste projets. suivi des projets scolaires", dateCreation: "10/06/2024 17:28", taches: []});
    // store.put({id: generateUniqueId(), nom: "Révisions", description: "Une petite description de la liste révisions. suivi des révisions scolaires", dateCreation: "10/02/2024 17:28", taches: []});
    // store.put({id: generateUniqueId(), nom: "Devoirs", description: "Une petite description de la liste devoirs. suivi des devoirs scolaires", dateCreation: "08/06/2024 17:28", taches: []});
    // store.put({id: generateUniqueId(), nom: "Devoirs2", description: "Une petite description de la liste devoirs. suivi des devoirs scolaires", dateCreation: "10/06/2024 17:28", taches: []});

    // const nomQuery = nomListeIndex.get("Projets");
    // const dateQuery = dateCreationListeIndex.getAll(["10-06-2024 17:28"]);

    // nomQuery.onsuccess = function () {
    //     console.log("nomQuery", nomQuery.result);
    // };
    // dateQuery.onsuccess = function () {
    //     console.log("dateQuery", dateQuery.result);
    // };


    // const store2 = transaction.objectStore("tache");
    // const nomTacheIndex = store2.index("indexNom");
    // const dateCreationTacheIndex = store2.index("indexDateCreation");

    // store2.put({id: generateUniqueId(), nom: "Réunion à 17h", description: "Une petite description de la liste projets. suivi des projets scolaires. Une petite description de la liste projets. suivi des projets scolaires", dateCreation: "10/06/2024 17:28", dateEcheance: "10/06/2024 17:28", statut: "Terminée", liste: 'Projets'});
    // store2.put({id: generateUniqueId(), nom: "Projet de BD", description: "Une petite description de la liste révisions. suivi des révisions scolaires", dateCreation: "10/02/2024 17:28", dateEcheance: "08/02/2024 17:28", statut: "Terminée", liste: 'Projets'});
    // store2.put({id: generateUniqueId(), nom: "Devoirs", description: "Une petite description de la liste devoirs. suivi des devoirs scolaires", dateCreation: "08/06/2024 17:28", dateEcheance: "10/06/2024 17:28", statut: "Oubliée", liste: 'Révisions'});
    // store2.put({id: generateUniqueId(), nom: "Devoirs2", description: "Une petite description de la liste devoirs. suivi des devoirs scolaires", dateCreation: "10/06/2024 17:28", dateEcheance: "12/06/2024 17:28", statut: "A faire", liste: 'Révisions'});

    // const nomTQuery = nomTacheIndex.get("Projet de BD");
    // const dateTQuery = dateCreationTacheIndex.getAll(["10-06-2024 17:28"]);

    // nomTQuery.onsuccess = function () {
    //     console.log("nomTQuery", nomTQuery.result);
    // };
    // dateTQuery.onsuccess = function () {
    //     console.log("dateTQuery", dateTQuery.result);
    // };

    // transaction.oncomplete = function () {
    //     db.close;
    // };
};

function generateUniqueId() {
    var timestamp = Date.now().toString(36); // Convertir l'horodatage en base 36
    var randomNum = Math.random().toString(36).slice(2, 7); // Générer un nombre aléatoire
    return timestamp + randomNum; // Concaténer l'horodatage et le nombre aléatoire
}


// $('#btnNotif').on("click", function () {
//     Notification.requestPermission().then(perm => {
//         alert(perm)
//         if (perm == 'granted'){
//         new Notification('Gestion des tâches', {
//             body: "content"
//         });
//     }
//     })
// });
