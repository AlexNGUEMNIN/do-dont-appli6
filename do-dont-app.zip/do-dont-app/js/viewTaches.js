
$(document).ready(function () {
    var tabTaches = [];
    var tachesContainer = document.querySelector("#tachesContainer");

    // Récupérer les paramètres de la requête dans l'URL
    const params = new URLSearchParams(window.location.search);
    const listId = params.get('listId');
    console.log(listId);

    var tabTaches = [];
    getListe(listId).then((liste) => {
        if (liste) {
            getAlltaches(liste.taches);
            tabTaches = liste.taches;
            console.log(liste.taches);
            console.log(tabTaches);
        }
    }).catch((error) => {
        console.error("Erreur lors de la récupération de la liste:", error);
    });


    // Cette fonction récupère les données des listes depuis IndexedDB et les utilise pour peupler la liste déroulante
    function peuplerListeDeroulante() {
        // Ouvrir la connexion à votre base de données IndexedDB
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function (event) {
            let db = event.target.result;
            let transaction = db.transaction(['liste'], 'readonly');
            let objectStore = transaction.objectStore('liste');
            let query = objectStore.getAll();

            query.onsuccess = function (event) {
                let data = event.target.result;

                // Sélectionner l'élément select
                let selectListe = document.getElementById('selectListe');
                let selectListeModif = document.getElementById('selectListeModif');

                // Boucler à travers les données et créer des options pour chaque liste
                data.forEach(function (item) {
                    let option = document.createElement('option');
                    option.textContent = item.nom;
                    option.value = item.nom;
                    selectListe.appendChild(option);
                });
                data.forEach(function (item) {
                    let option = document.createElement('option');
                    option.textContent = item.nom;
                    option.value = item.nom;
                    selectListeModif.appendChild(option);
                });
            };
        };
    }

    peuplerListeDeroulante();

    function getListe(key) {
        return new Promise((resolve, reject) => {
            const request = openBD();
            request.onerror = function (event) {
                console.error("Une erreur avec IndexedDB");
                console.error(event);
                reject(event);
            };

            request.onsuccess = function () {
                const db = request.result;
                const transaction = db.transaction("liste", "readonly");
                const store = transaction.objectStore("liste");

                const query = store.get(key);
                query.onsuccess = function () {
                    const liste = query.result;
                    resolve(liste);
                };

                transaction.oncomplete = function () {
                    db.close(); // Fermer la base de données
                };
            };
        });
    }

    function getAlltaches(taches) {
        const keyword = $('#searchInput').val().trim().toLowerCase();
        console.log(keyword);
        const filteredTasks = filterTasksByKeyword(taches, keyword);
        console.log(filteredTasks);
        for (let elt of filteredTasks) {
            const statutBadge = getStatusBadge(elt.statut, elt.id);
            let modifierButton = ''; // Initialiser une variable pour stocker le bouton modifier
            // Vérifier si le statut de la tâche est différent de "Terminée"
            if (elt.statut !== 'Terminée') {
                modifierButton = `<button type="button" class="btn btn-warning bg-light text-warning border-0 p-1 me-1 modalModifTacheOpen" data-key="${elt.id}"
            data-nom="${elt.nom}" data-desc="${elt.description}" data-eche="${elt.dateEcheance}" data-liste="${elt.liste}"><i class="fa fa-pen"></i></button>`;
            }
            const liste = `<div class="col-md-6 col-lg-4">
            <div class="bg-light rounded">
                <div class="card-body" name="cardListe"">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="mb-0">
                            <h5 class="card-title">${elt.nom}</h5>
                        </div>
                        <div class="d-flex">
                            ${modifierButton} <!-- Utilisation de la variable modifierButton -->
                            <button type="button" class="btn btn-danger text-danger bg-light border-0 p-1 modalSupListeOpen"
                                data-key="${elt.id}"><i class="fa fa-trash"></i></button>
                        </div>
                    </div>
                    
                    <div class="card-subtitle text-muted mb-3">${elt.dateCreation}</div>
                    <p class="card-text scroll">
                        ${elt.description}
                    </p>
                    <p class="card-text">
                        Date d'échéance : ${elt.dateEcheance}
                    </p>
                    <a href="javascript:void(0)" class="card-link">${elt.liste}</a>
                    ${statutBadge}
                </div>
            </div>
        </div>`
            tachesContainer.insertAdjacentHTML("beforeend", liste);
        }
        addEventUpdate();
        addEventDelete();
        addEventUpdateStatutEncours();
        addEventUpdateStatutTerminee();
    }


    function openBD() {
        const indexedDB = window.indexedDB ||
            window.mozIndexedDB ||
            window.webkitIndexedDB ||
            window.msIndexedDB ||
            window.shimIndexedDB;

        const request = indexedDB.open("ddDatabase", 1);
        return request;
    }

    function getStatusBadge(statut, id) {
        switch (statut) {
            case "Terminée":
                return `<span class="card-link badge bg-success">Terminée</span>`;
            case "Oubliée":
                return `<span class="card-link badge bg-danger">Oubliée</span>`;
            case "En cours":
                return `<a href="javascript:void(0)" class="card-link dropdown-toggle dropdown-toggle-no-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="badge bg-warning">En cours</span></a><ul class="dropdown-menu"><li><a data-key="${id}" id="terminee" class="dropdown-item" href="javascript:void(0);">Terminée</a></ul>`;
            case "A faire":
                return `<a href="javascript:void(0)" class="card-link dropdown-toggle dropdown-toggle-no-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="badge bg-secondary">A faire</span></a><ul class="dropdown-menu"><li><a data-key="${id}" id="encours" class="dropdown-item" href="javascript:void(0);">En cours</a></ul>`;
            default:
                return '';
        }
    }

    var tachesContainer = document.querySelector("#tachesContainer");
    var statutAffichage = "grilleSimple"; // grilleListe grilleDateEcheance listeSimple listeListe listeDateEcheance


    function formatDate(date) {
        const options = { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' };
        return new Date(date).toLocaleDateString('fr-FR', options);
    }

    function convertToDate(dateString) {
        // Séparation de la date et de l'heure
        var dateParts = dateString.split(' ');
        var datePart = dateParts[0];
        var timePart = dateParts[1];

        // Séparation du jour, mois, année
        var dateComponents = datePart.split('/');
        var day = parseInt(dateComponents[0]);
        var month = parseInt(dateComponents[1]) - 1; // Les mois commencent à partir de zéro dans JavaScript
        var year = parseInt(dateComponents[2]);

        // Séparation de l'heure et des minutes
        var timeComponents = timePart.split(':');
        var hour = parseInt(timeComponents[0]);
        var minute = parseInt(timeComponents[1]);

        // Création de l'objet Date
        var dateObject = new Date(year, month, day, hour, minute);

        return dateObject
    }

    function masquerAlert(alert) {
        alert.classList.add('fade'); // Ajoute la classe fade pour une transition de fermeture en douceur
        setTimeout(function () {
            alert.setAttribute('hidden', true); // Masquez le modal après 5 secondes (5000 millisecondes)
        }, 5000);
    }


    function deleteTache() {
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function () {
            const db = request.result;
            // Démarrer une transaction en mode de lecture/écriture sur la table "liste"
            const transaction = db.transaction(["tache", "liste"], "readwrite");
            const store = transaction.objectStore("tache");
            const store2 = transaction.objectStore("liste");
            const nomListeIndex = store2.index("indexNom");

            var key = $('#messageSuppresion').attr("data-key");
            console.log(key);
            var getRequest = store.get(key);
            getRequest.onsuccess = function (event) {
                var tache = event.target.result;
                console.log(tache);
                let liste = tache.liste;
                var deleteRequest = store.delete(key);
                deleteRequest.onsuccess = function (event) {
                    var getListeRequest = nomListeIndex.get([liste]);
                    getListeRequest.onsuccess = function (event) {
                        var l = event.target.result;
                        console.log(l);
                        for (let i in l.taches) {
                            if ((l.taches[i]).id == key) {
                                console.log('l.taches[i]', l.taches[i])
                                l.taches.splice(i, 1);
                            }
                        }
                        var updateListeRequest = store2.put(l);
                        updateListeRequest.onsuccess = function (event) {
                            console.log('Tâche supprimée avec succès.');
                            $('#modalSup').modal("hide");
                            $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Tâche supprimée avec succès! ");
                            let alert_success_add = document.getElementById("alert_success_add");
                            alert_success_add.removeAttribute('hidden'); // Affichez le modal
                            masquerAlert(alert_success_add);
                            $('#tachesContainer').html("");
                            getAlltaches(tabTaches);
                            location.reload();
                        }
                    };
                };
            }
        }

        deleteRequest.onerror = function (event) {
            console.error('Erreur lors de la suppression de la tâche.');
            console.log(event);
            $('#modalSup').modal("hide");
            $('#alert_error_add').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la suppression de la tâche. ");
            let alert_error_add = document.getElementById("alert_error_add");
            alert_error_add.removeAttribute('hidden'); // Affichez le modal
            masquerAlert(alert_error_add);
        }
        transaction.oncomplete = function () {
            db.close;
        };
    }

    let nomTacheM = "";
    let descriptionTacheM = "";
    let dateFinM = "";
    let heureFinM = "";
    let listeM = "";
    $('#inputNomModif').on('input', function (elt) {
        nomTacheM = $(this).val();
    });
    $('#inputDescriptionModif').on('input', function (elt) {
        descriptionTacheM = $(this).val();
    });
    $('#inputDateModif').on('input', function (elt) {
        dateFinM = $(this).val();
    });
    $('#inputHeureModif').on('input', function (elt) {
        heureFinM = $(this).val();
    });
    $('#selectListeModif').on('change', function () {
        listeM = $(this).val();
        console.log('listeM : ', listeM);
    });

    function updateTache() {
        console.log("debut modif");
        //var listeM = $("#selectListeModif").val();
        let formModif = document.getElementById('formModif');
        let champsRequis = formModif.querySelectorAll('[required]');
        let formSussess = true;
        for (let champ of champsRequis) {
            // Vérifiez si le champ est vide
            if (champ.value.trim() === '') {
                formSussess = false;
                // Affichez un message d'erreur
                $('#alert_error_Modif').html("<i class='fa fa-exclamation-circle me-2'></i>Veuillez remplir tous les champs obligatoires.");
                let alert_error_Modif = document.getElementById("alert_error_Modif");
                alert_error_Modif.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_Modif);
            }
        }

        if (formSussess) {
            nowDate = new Date();
            // Séparer la date en année, mois et jour
            let [year, month, day] = dateFinM.split('-').map(Number);
            // Séparer l'heure en heures et minutes
            let [hours, minutes] = heureFinM.split(':').map(Number);
            // Créer un objet Date en utilisant les valeurs extraites
            let dateHeureFinM = new Date(year, month - 1, day, hours, minutes);
            if (nowDate >= dateHeureFinM) {
                // Affichez un message d'erreur
                $('#alert_error_Modif').html("<i class='fa fa-exclamation-circle me-2'></i>La date d'échéance est passée.");
                let alert_error_Modif = document.getElementById("alert_error_Modif");
                alert_error_Modif.removeAttribute('hidden'); // Affichez le modal
                masquerAlert(alert_error_Modif);
            } else {
                const request = openBD();
                request.onerror = function (event) {
                    console.error("Une erreur avec IndexedDB");
                    console.error(event);
                };
                request.onsuccess = function () {
                    const db = request.result;
                    const transaction = db.transaction(["tache", "liste"], "readwrite");
                    const store = transaction.objectStore("tache");
                    const nomTacheListeIndex = store.index("indexNom_Liste");
                    const store2 = transaction.objectStore("liste");
                    const nomListeIndex = store2.index("indexNom");

                    var key = $('#inputNomModif').attr("data-key");
                    console.log(key);
                    var getRequest = store.get(key);
                    getRequest.onsuccess = function (event) {
                        var tache = event.target.result;
                        console.log(tache);
                        let oldListe = tache.liste;

                        // Modifier les propriétés de l'objet
                        tache.nom = nomTacheM; // Nouveau nom
                        tache.description = descriptionTacheM; // Nouvelle description
                        tache.dateEcheance = formatDate(dateHeureFinM);
                        tache.liste = listeM;

                        // Mettre à jour l'objet modifié dans la base de données en utilisant put()
                        var updateRequest = store.put(tache);
                        // Gérer le succès ou l'échec de la requête de mise à jour
                        updateRequest.onsuccess = function (event) {
                            const query = nomTacheListeIndex.get([nomTacheM, listeM]);
                            query.onsuccess = function () {
                                console.log("query", query.result);
                                var getListeRequest = nomListeIndex.get([listeM]);
                                getListeRequest.onsuccess = function (event) {
                                    var l = event.target.result;
                                    console.log(l);
                                    if (oldListe == listeM) {
                                        // Modifier les propriétés de l'objet
                                        for (let i in l.taches) {
                                            if ((l.taches[i]).id == key) {
                                                console.log('l.taches[i]', l.taches[i])
                                                l.taches[i] = query.result;
                                            }
                                        }
                                        // Mettre à jour l'objet modifié dans la base de données en utilisant put()
                                        var updateListeRequest = store2.put(l);
                                        // Gérer le succès ou l'échec de la requête de mise à jour
                                        updateListeRequest.onsuccess = function (event) {
                                            $('#modalModif').modal("hide");
                                            $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Tache modifiée avec succès! ");
                                            let alert_success_add = document.getElementById("alert_success_add");
                                            alert_success_add.removeAttribute('hidden'); // Affichez le modal
                                            masquerAlert(alert_success_add);
                                            $('#tachesContainer').html("");
                                            getAlltaches(tabTaches);
                                        }
                                    } else {

                                        var getOldListeRequest = nomListeIndex.get([oldListe]);
                                        getOldListeRequest.onsuccess = function (event) {
                                            var ol = event.target.result;
                                            console.log(ol);
                                            // Modifier les propriétés de l'objet
                                            for (let i in ol.taches) {
                                                if ((ol.taches[i]).id == key) {
                                                    console.log('ol.taches[i]', ol.taches[i])
                                                    ol.taches.splice(i, 1);
                                                }
                                            }
                                            l.taches.push(query.result);
                                            // Mettre à jour l'objet modifié dans la base de données en utilisant put()

                                            var updateOldListeRequest = store2.put(ol);
                                            // Gérer le succès ou l'échec de la requête de mise à jour
                                            updateOldListeRequest.onsuccess = function (event) {
                                                var updateListeRequest = store2.put(l);
                                                updateListeRequest.onsuccess = function (event) {
                                                    $('#modalModif').modal("hide");
                                                    $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Tache modifiée avec succès! ");
                                                    let alert_success_add = document.getElementById("alert_success_add");
                                                    alert_success_add.removeAttribute('hidden'); // Affichez le modal
                                                    masquerAlert(alert_success_add);
                                                    $('#tachesContainer').html("");
                                                    getAlltaches(tabTaches);
                                                }
                                            }
                                        };
                                    };
                                };
                            };
                        };
                        updateRequest.onerror = function (event) {
                            console.log(event);
                            // Vérifier si l'erreur est due à une contrainte d'unicité sur l'attribut "nom, liste"
                            if (event.target.error && event.target.error.name === 'ConstraintError') {
                                $('#alert_error_Modif').html("<i class='fa fa-exclamation-circle me-2'></i>Ce nom de tâche existe déjà dans cette liste.");
                                let alert_error_Modif = document.getElementById("alert_error_Modif");
                                alert_error_Modif.removeAttribute('hidden'); // Affichez le modal
                                masquerAlert(alert_error_Modif);
                                console.error('Le nom de liste existe déjà.');
                            } else {
                                $('#alert_error_Modif').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la modification de la tâche.");
                                let alert_error_Modif = document.getElementById("alert_error_Modif");
                                alert_error_Modif.removeAttribute('hidden'); // Affichez le modal
                                masquerAlert(alert_error_Modif);
                                console.error('Erreur lors de la modification de la liste :', event.target.error);
                            }
                        };
                        transaction.oncomplete = function () {
                            db.close;
                        };
                    }
                }
            }
        }
    }

    $('#deleteTacheBtn').on("click", function () {
        deleteTache()
    });

    function addEventUpdate() {
        // Ajouter un écouteur d'événement pour chaque bouton "modifier"
        const modifButtons = document.querySelectorAll('.modalModifTacheOpen');
        modifButtons.forEach(button => {
            button.addEventListener('click', function () {
                const nomData = this.getAttribute('data-nom');
                const descData = this.getAttribute('data-desc');
                const dateEcheData = this.getAttribute('data-eche');
                const listeData = this.getAttribute('data-liste');
                const keyData = this.getAttribute('data-key');
                // Ouvrir le modal de modification et pré-remplir le formulaire avec les informations de la liste
                openModificationModal(nomData, descData, dateEcheData, listeData, keyData);
            });
        });
    }
    function addEventDelete() {
        // Ajouter un écouteur d'événement pour chaque bouton "supprimer"
        const supButtons = document.querySelectorAll('.modalSupListeOpen');
        supButtons.forEach(button => {
            button.addEventListener('click', function () {
                const keyData = this.getAttribute('data-key');
                // Ouvrir le modal de confirmation de la suppression
                openSuppressionModal(keyData);
            });
        });
    }
    function addEventUpdateStatutEncours() {
        const encoursButtons = document.querySelectorAll('#encours');
        encoursButtons.forEach(button => {
            button.addEventListener('click', function () {
                const key = this.getAttribute('data-key');
                changeStatut("En cours", key);
            });
        });
    }
    function addEventUpdateStatutTerminee() {
        const termineeButtons = document.querySelectorAll('#terminee');
        termineeButtons.forEach(button => {
            button.addEventListener('click', function () {
                const key = this.getAttribute('data-key');
                changeStatut("Terminée", key);
            });
        });
    }

    function openModificationModal(nom, description, dateEcheance, liste, id) {
        // Diviser la chaîne en date et heure
        var dateParts = dateEcheance.split(' ');
        var dateValue = dateParts[0];
        var datePartsFormatted = dateValue.split('/');
        var dateValueFormatted = datePartsFormatted[2] + '-' + datePartsFormatted[1] + '-' + datePartsFormatted[0];
        var timeValue = dateParts[1];
        $('#inputNomModif').val(nom);
        $('#inputNomModif').attr("data-key", id);
        $('#inputDescriptionModif').val(description);
        $('#inputDateModif').val(dateValueFormatted);
        $('#inputHeureModif').val(timeValue);
        $('#selectListeModif').val(liste);
        nomTacheM = nom;
        descriptionTacheM = description;
        dateFinM = $('#inputDateModif').val();
        heureFinM = timeValue;
        listeM = liste;
        $('#modalModif').modal("show");
    }

    function openSuppressionModal(id) {
        $('#messageSuppresion').attr("data-key", id);
        $('#modalSup').modal("show");
    }
    $('#updateTacheBtn').on("click", function () {
        updateTache()
    });

    function changeStatut(newStatut, key) {
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };
        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction(["tache", "liste"], "readwrite");
            const store = transaction.objectStore("tache");
            const store2 = transaction.objectStore("liste");
            const nomListeIndex = store2.index("indexNom");
            console.log(key);
            var getRequest = store.get(key);
            getRequest.onsuccess = function (event) {
                var tache = event.target.result;
                console.log(tache);
                tache.statut = newStatut;
                var updateRequest = store.put(tache);
                updateRequest.onsuccess = function (event) {
                    const query = store.get(key);
                    query.onsuccess = function () {
                        console.log("query", query.result);
                        var getListeRequest = nomListeIndex.get([tache.liste]);
                        getListeRequest.onsuccess = function (event) {
                            var l = event.target.result;
                            console.log(l);
                            for (let i in l.taches) {
                                if ((l.taches[i]).id == key) {
                                    console.log('l.taches[i]', l.taches[i])
                                    l.taches[i] = query.result;
                                }
                            }
                            var updateListeRequest = store2.put(l);
                            updateListeRequest.onsuccess = function (event) {
                                $('#modalModif').modal("hide");
                                $('#alert_success_add').html("<i class='fa fa-exclamation-circle me-2'></i>Statut de la tâche mis à jour avec succès! ");
                                let alert_success_add = document.getElementById("alert_success_add");
                                alert_success_add.removeAttribute('hidden'); // Affichez le modal
                                masquerAlert(alert_success_add);
                                $('#tachesContainer').html("");
                                getAlltaches(tabTaches);
                            }
                        };
                    };
                };
                updateRequest.onerror = function (event) {
                    console.log(event);
                    $('#alert_error_Modif').html("<i class='fa fa-exclamation-circle me-2'></i>Erreur lors de la mise à jour du statut de la tâche.");
                    let alert_error_Modif = document.getElementById("alert_error_Modif");
                    alert_error_Modif.removeAttribute('hidden'); // Affichez le modal
                    masquerAlert(alert_error_Modif);
                    console.error('Erreur lors de la modification de la liste :', event.target.error);
                };
                transaction.oncomplete = function () {
                    db.close;
                };
            }
        }
        // location.reload()
    }

    function changeStatusToOubliee() {
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction("tache", "readonly");
            const store = transaction.objectStore("tache");
            let taches = [];

            store.openCursor().onsuccess = function (event) {
                var cursor = event.target.result;
                if (cursor) {
                    // Ajouter la tâche à la liste
                    taches.push(cursor.value);
                    cursor.continue();
                } else {
                    // // Fermer la transaction et la base de données
                    // transaction.oncomplete = function () {
                    //     db.close;
                    // };

                    // // Traiter les tâches récupérées
                    // traiterTaches(taches);
                    // Créer une promesse pour la fermeture de la base de données
                    var closePromise = new Promise(function (resolve, reject) {
                        // Attacher un gestionnaire à l'événement oncomplete de la transaction
                        transaction.oncomplete = function () {
                            db.close(); // Fermer la base de données
                            resolve(); // Résoudre la promesse une fois que la base de données est fermée
                        };
                    });

                    // Attendre que la promesse de fermeture de la base de données soit résolue
                    closePromise.then(function () {
                        // Une fois que la base de données est fermée, appeler la fonction pour traiter les tâches
                        traiterTaches(taches);
                    });
                }
            };
        };
    }

    function traiterTaches(taches) {
        var dateActuelle = new Date();

        taches.forEach(function (tache) {
            var dateEcheance = convertToDate(tache.dateEcheance);
            // Vérifier si le statut de la tâche est 'En cours' ou 'A faire'
            if ((tache.statut === 'En cours' || tache.statut === 'A faire') && (dateEcheance < dateActuelle)) {
                // Changer le statut de la tâche en 'Oubliée'
                changeStatut('Oubliée', tache.id);
            }
        });
    }

    function affichageListe() {
        $('#tachesContainer').html("");
        console.log("affichageListe");
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction("liste", "readonly");
            const store = transaction.objectStore("liste");

            const keyword = $('#searchInput').val().trim().toLowerCase();
            console.log(keyword);

            const query = store.getAll();
            query.onsuccess = function () {
                for (let liste of query.result) {
                    const filteredTasks = filterTasksByKeyword(liste.taches, keyword);
                    if (filteredTasks.length != 0) {
                        const l = `<div><h5 class="mt-3 text-primary">${liste.nom}</h5><div class="row g-4" id="${liste.nom}"></div></div>`
                        tachesContainer.insertAdjacentHTML("beforeend", l);
                        for (let elt of filteredTasks) {
                            console.log("elt for : ", elt);
                            const statutBadge = getStatusBadge(elt.statut, elt.id);
                            let modifierButton = ''; // Initialiser une variable pour stocker le bouton modifier
                            // Vérifier si le statut de la tâche est différent de "Terminée"
                            if (elt.statut !== 'Terminée') {
                                modifierButton = `<button type="button" class="btn btn-warning bg-light text-warning border-0 p-1 me-1 modalModifTacheOpen" data-key="${elt.id}"
                                data-nom="${elt.nom}" data-desc="${elt.description}" data-eche="${elt.dateEcheance}" data-liste="${elt.liste}"><i class="fa fa-pen"></i></button>`;
                            }
                            const tache = `<div class="col-md-6 col-lg-4">
                                <div class="bg-light rounded">
                                    <div class="card-body" name="cardListe"">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="mb-0">
                                                <h5 class="card-title">${elt.nom}</h5>
                                            </div>
                                            <div class="d-flex">
                                                ${modifierButton} <!-- Utilisation de la variable modifierButton -->
                                                <button type="button" class="btn btn-danger text-danger bg-light border-0 p-1 modalSupListeOpen"
                                                    data-key="${elt.id}"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </div>
                                        
                                        <div class="card-subtitle text-muted mb-3">${elt.dateCreation}</div>
                                        <p class="card-text scroll">
                                            ${elt.description}
                                        </p>
                                        <p class="card-text">
                                            Date d'échéance : ${elt.dateEcheance}
                                        </p>
                                        ${statutBadge}
                                    </div>
                                </div>
                            </div>`
                            var listeRow = document.getElementById(liste.nom);
                            listeRow.insertAdjacentHTML("beforeend", tache);
                        }
                    }
                }
                addEventUpdate();
                addEventDelete();
                addEventUpdateStatutEncours();
                addEventUpdateStatutTerminee();
            };

            transaction.oncomplete = function () {
                db.close;
            };
        };
    };

    $('#affichageListeBtn').on("click", function () {
        statutAffichage = "grilleListe";
        affichageListe();
    });
    $('#affichageGrilleBtn').on("click", function () {
        statutAffichage = "grilleSimple";
        getAlltaches(tabTaches);
    });

    // Fonction pour organiser les tâches par date d'échéance
    function organiserTachesParDate(taches) {
        const tachesParDate = {};
        taches.forEach(tache => {
            const dateEcheance = tache.dateEcheance;
            if (!tachesParDate[dateEcheance]) {
                tachesParDate[dateEcheance] = [];
            }
            tachesParDate[dateEcheance].push(tache);
        });
        return tachesParDate;
    }

    function affichageDateEcheance() {
        $('#tachesContainer').html("");
        console.log("affichageDateEcheance");
        const request = openBD();
        request.onerror = function (event) {
            console.error("Une erreur avec IndexedDB");
            console.error(event);
        };

        request.onsuccess = function () {
            const db = request.result;
            const transaction = db.transaction("tache", "readonly");
            const store = transaction.objectStore("tache");

            const keyword = $('#searchInput').val().trim().toLowerCase();
            console.log(keyword);

            const query = store.getAll();
            query.onsuccess = function () {
                const filteredTasks = filterTasksByKeyword(query.result, keyword);
                let tachesParDate = organiserTachesParDate(filteredTasks);
                for (const date in tachesParDate) {
                    const taches = tachesParDate[date];
                    const d = `<div><h5 class="mt-3 text-primary">${date}</h5><div class="row g-4" id="${date}"></div></div>`
                    tachesContainer.insertAdjacentHTML("beforeend", d);
                    for (let elt of taches) {
                        const statutBadge = getStatusBadge(elt.statut, elt.id);
                        let modifierButton = ''; // Initialiser une variable pour stocker le bouton modifier
                        // Vérifier si le statut de la tâche est différent de "Terminée"
                        if (elt.statut !== 'Terminée') {
                            modifierButton = `<button type="button" class="btn btn-warning bg-light text-warning border-0 p-1 me-1 modalModifTacheOpen" data-key="${elt.id}"
                                data-nom="${elt.nom}" data-desc="${elt.description}" data-eche="${elt.dateEcheance}" data-liste="${elt.liste}"><i class="fa fa-pen"></i></button>`;
                        }
                        const tache = `<div class="col-md-6 col-lg-4">
                                <div class="bg-light rounded">
                                    <div class="card-body" name="cardListe"">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="mb-0">
                                                <h5 class="card-title">${elt.nom}</h5>
                                            </div>
                                            <div class="d-flex">
                                                ${modifierButton} <!-- Utilisation de la variable modifierButton -->
                                                <button type="button" class="btn btn-danger text-danger bg-light border-0 p-1 modalSupListeOpen"
                                                    data-key="${elt.id}"><i class="fa fa-trash"></i></button>
                                            </div>
                                        </div>
                                        
                                        <div class="card-subtitle text-muted mb-3">${elt.dateCreation}</div>
                                        <p class="card-text scroll">
                                            ${elt.description}
                                        </p>
                                        <p class="card-text">
                                            Date d'échéance : ${elt.dateEcheance}
                                        </p>
                                        <a href="javascript:void(0)" class="card-link">${elt.liste}</a>
                                        ${statutBadge}
                                    </div>
                                </div>
                            </div>`
                        var dateRow = document.getElementById(date);
                        dateRow.insertAdjacentHTML("beforeend", tache);
                    }
                }
                addEventUpdate();
                addEventDelete();
                addEventUpdateStatutEncours();
                addEventUpdateStatutTerminee();
            };

            transaction.oncomplete = function () {
                db.close;
            };
        };
    };

    $('#affichageDateEcheanceBtn').on("click", function () {
        statutAffichage = "grilleDateEcheance";
        affichageDateEcheance();
    });

    changeStatusToOubliee();


    // Fonction de filtrage des tâches en fonction du mot-clé de recherche
    function filterTasksByKeyword(tasks, keyword) {
        console.log('keyword', keyword);
        console.log('tasks', tasks);
        return tasks.filter(task => {
            console.log(task);
            return task.nom.toLowerCase().includes(keyword) || task.description.toLowerCase().includes(keyword) || task.dateCreation.includes(keyword) || task.dateEcheance.includes(keyword);
        });
    }

    $('#searchForm').on('submit', function (event) {
        event.preventDefault();
    });

    $('#searchInput').on('input', function () {
        getAlltaches(tabTaches);
    });
});
